# Drivers
🏎simple formulas to build highly efficient scripts


## deploy

`python3 setup.py sdist`

## publish

`python3 -m twine upload dist/* -u YOUR_USERNAME`
